# Equity Momentum Under Complete Trial Accounting: A Selected Survivor and Failed Deep-History Replication — corrections ledger

No bundle-version correction has been recorded. This empty ledger is not a claim that the underlying research lineage contains no corrections; those remain in `paper.md`.
