import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createHash } from 'node:crypto';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { gzipSync } from 'node:zlib';
import { execFileSync } from 'node:child_process';

const root = resolve(process.argv[2]);
const moduleRoot = join(root, 'scripts/datasets/filing-facts/v1');
const { candidatesForArchive } = await import(pathToFileURL(join(moduleRoot, 'generate.mjs')));
const { readArchive } = await import(pathToFileURL(join(moduleRoot, 'source.mjs')));
const { checkCandidate, checkCandidates } = await import(pathToFileURL(join(moduleRoot, 'check.mjs')));
const { candidateId } = await import(pathToFileURL(join(moduleRoot, 'contract.mjs')));
const scratch = fs.mkdtempSync(join(tmpdir(), 'canli-v1-primary-source-'));
const hash = b => createHash('sha256').update(b).digest('hex');
const cases = [];
let sequence = 0;
const first = { start: '2019-01-01', end: '2019-12-31', val: 80, filed: '2020-02-29', accn: '0000000001-20-000003', form: '10-K', fp: 'FY', fy: 2019 };
const last = { ...first, val: 200, filed: '2021-03-01', accn: '0000000001-21-000004', form: '10-K/A', fy: 2020 };
function fixture(rows, modify = () => {}) {
  const dir = join(scratch, String(sequence++)); fs.mkdirSync(dir);
  const snapshots = join(dir, 'sources'); fs.mkdirSync(snapshots);
  const facts = { cik: 1, entityName: 'Independent synthetic source', facts: { 'us-gaap': { NetIncomeLoss: { units: { USD: rows } } } } };
  modify(facts);
  const bytes = Buffer.from(JSON.stringify(facts)); const digest = hash(bytes);
  fs.writeFileSync(join(snapshots, digest + '.json.gz'), gzipSync(bytes));
  const recordPath = join(dir, '0000000001.json');
  fs.writeFileSync(recordPath, JSON.stringify({ schema: 'canli.company-reference.v1', cik: '0000000001', name: facts.entityName, source_sha256: digest, source_url: 'https://data.sec.gov/api/xbrl/companyfacts/CIK0000000001.json', fetched_at: '2024-01-01T00:00:00Z' }));
  return { dir, snapshots, recordPath, archive: readArchive(recordPath, snapshots) };
}
const generate = (f, asOf = '2023-12-31') => candidatesForArchive(f.archive, { asOf, limit: 100 });
function probe(name, fn) { fn(); cases.push({ name, passed: true }); }
let tamperCases = 0;
try {
  probe('335 and395 day inclusive boundaries accepted;334 and396 rejected', () => {
    for (const days of [334, 335, 395, 396]) {
      const end = new Date(Date.parse(first.start) + (days - 1) * 86400000).toISOString().slice(0, 10);
      const f = fixture([{ ...first, end }, { ...last, end }]);
      assert.equal(generate(f).candidates.length, days === 335 || days === 395 ? 1 : 0);
    }
  });
  probe('cutoff inclusive and post-cutoff source rows excluded', () => {
    const f = fixture([last, { ...last, val: 300, filed: '2022-04-01', accn: '0000000001-22-000001' }, first]);
    assert.equal(generate(f, last.filed).candidates[0].later.value, 200);
    assert.equal(generate(f, first.filed).candidates.length, 0);
  });
  probe('same-day ambiguity in intermediate observations refuses entire group', () => {
    const middle = { ...last, filed: '2020-06-01', accn: '0000000001-20-000009', val: 90 };
    assert.equal(generate(fixture([first, middle, { ...middle, accn: '0000000001-20-000010', val: 91 }, last])).candidates.length, 0);
  });
  probe('same accession with changed fiscal metadata refuses; exact duplicates deduplicate', () => {
    assert.equal(generate(fixture([first, { ...first, fy: 2018 }, last])).candidates.length, 0);
    assert.equal(generate(fixture([first, { ...first }, last])).candidates[0].eligible_accessions, 2);
  });
  probe('annual rows in10-Q and differing units/taxonomy cannot change endpoint', () => {
    const f = fixture([first, last, { ...last, val: 999, filed: '2022-04-01', accn: '0000000001-22-000001', form: '10-Q' }], facts => {
      facts.facts['us-gaap'].NetIncomeLoss.units.EUR = [{ ...last, val: 9999 }];
      facts.facts.ifrs = { NetIncomeLoss: { units: { USD: [{ ...last, val: 99999 }] } } };
    });
    assert.equal(generate(f).candidates[0].later.value, 200);
  });
  probe('reversion counted, zero denominator null, negative denominator uses magnitude', () => {
    const reverted = generate(fixture([first, last, { ...last, val: first.val, filed: '2022-04-01', accn: '0000000001-22-000001' }]));
    assert.equal(reverted.report.rejected_groups.reverted_at_cutoff, 1);
    const zero = generate(fixture([{ ...first, val: 0 }, last])).candidates[0];
    assert.equal(zero.answer.percent_difference, null); assert.equal(zero.answer.percent_difference_status, 'zero_earliest');
    const negative = generate(fixture([{ ...first, val: -80 }, { ...last, val: -40 }])).candidates[0];
    assert.equal(negative.answer.percent_difference, 50);
  });
  probe('fractional values and unsafe differences refuse', () => {
    assert.equal(generate(fixture([first, { ...last, val: 200.5 }])).candidates.length, 0);
    assert.equal(generate(fixture([{ ...first, val: -Number.MAX_SAFE_INTEGER }, { ...last, val: Number.MAX_SAFE_INTEGER }])).candidates.length, 0);
  });
  probe('every candidate leaf mutation refuses after attacker recomputes content ID', () => {
    const f = fixture([first, last]); const item = generate(f).candidates[0];
    const leaves = [];
    function visit(v, path = []) {
      if (v && typeof v === 'object') for (const [key, value] of Object.entries(v)) visit(value, [...path, key]);
      else if (path[0] !== 'id') leaves.push([path, v]);
    }
    visit(item);
    for (const [path, value] of leaves) {
      const copy = structuredClone(item); let target = copy;
      for (const key of path.slice(0, -1)) target = target[key];
      target[path.at(-1)] = typeof value === 'string' ? value + ' altered' : typeof value === 'number' ? value + 1 : typeof value === 'boolean' ? !value : 1;
      copy.id = candidateId(copy);
      assert.equal(checkCandidate(copy, f.recordPath, f.snapshots).valid, false, path.join('.')); tamperCases++;
    }
    const count = checkCandidates([item, item, null], f.dir, f.snapshots);
    assert.equal(count.passed, 1); assert.equal(count.failed, 2);
  });
  const result = { schema: 'canli.filingfacts-v1-primary-source-probes.v1', observed_at: new Date().toISOString(), reviewed_head: execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(), node: process.version, cases, candidate_leaf_mutations_refused: tamperCases, source_hashes: Object.fromEntries(['generate.mjs', 'check.mjs', 'source.mjs', 'contract.mjs'].map(n => [n, hash(fs.readFileSync(join(moduleRoot, n)))])), limits: ['Independent synthetic source/selection/binding probes; not additional expert review, source-authenticity or complete-history evidence.', 'CLI alias finding is retained separately; this source probe pass does not approve a head with that unresolved CLI bug.'] };
  console.log(JSON.stringify(result, null, 2));
} finally { fs.rmSync(scratch, { recursive: true, force: true }); }
