import hashlib
import json
import os
import signal
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/Users/arhancanli/canlicapital-filingfacts-baseline-contract-20261001')
HEAD = '244c3e3969ca844fe54ee277f0c18502628be1ba'
OWNER = '01a0f6ba-8819-7f53-8226-3b0889eca2bf'
NODE = '/Users/arhancanli/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node'
LOCK = Path('/Users/arhancanli/traceaxiom-coordination-claude-codex/HEAVY.lock')
OUT = HERE / 'attempt-1'

def now():
    return datetime.now(timezone.utc).isoformat()

def save(path, value):
    with path.open('x') as handle:
        handle.write(json.dumps(value, indent=2) + '\n')

def pg_absent(pgid):
    try:
        os.killpg(pgid, 0)
        return False
    except ProcessLookupError:
        return True

if '--worker' in sys.argv:
    claim = json.loads(LOCK.read_bytes())
    assert claim['owner_thread'] == OWNER and claim['nonce'] == os.environ['CANLI_SMOKE_NONCE']
    cli = 'scripts/datasets/filing-facts/baseline-contract-cli.mjs'
    commands = [
        ('focused-tests', [NODE, '--test', '--test-concurrency=1',
          'scripts/datasets/filing-facts/baseline-contract.test.mjs',
          'scripts/datasets/filing-facts/eval.test.mjs', 'scripts/datasets/filing-facts/evidence.test.mjs']),
        ('prepare', [NODE, cli, 'prepare', str(ROOT), str(OUT / 'plan.json')]),
        ('audit', [NODE, cli, 'audit', str(ROOT), str(OUT / 'plan.json')]),
        ('questions', [NODE, cli, 'questions', str(ROOT), str(OUT / 'plan.json'), str(OUT / 'questions.json')]),
    ]
    for name, command in commands:
        started = now()
        tick = time.monotonic()
        with (OUT / (name + '.log')).open('xb') as log:
            result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        save(OUT / (name + '-terminal.json'), {'stage': name, 'command': command, 'started_at': started,
          'ended_at': now(), 'seconds': time.monotonic() - tick, 'exit_code': result.returncode})
        if result.returncode:
            sys.exit(result.returncode)
    sys.exit(0)

grant = json.loads((HERE / 'capacity-grant-final.json').read_bytes())
ready = json.loads((HERE / 'predecessor-closure-current.json').read_bytes())
assert grant['lead_explicit_conditional_grant'] and grant['source'] == HEAD
assert datetime.now(timezone.utc) < datetime.fromisoformat(grant['latestClaimBefore'])
ack = grant['sourcePrimaryAcknowledgement']
assert hashlib.sha256(Path(ack['path']).read_bytes()).hexdigest() == ack['sha256']
assert all(hashlib.sha256((ROOT / row['path']).read_bytes()).hexdigest() == row['sha256'] for row in grant['sourceAnd12BindingsVerified'])
assert ready['lead_or_observer_relay'] and ready['actual_terminal_observed'] and ready['owned_process_group_absent'] and ready['guarded_released']
assert ready['predecessor'] == 'curivela_control_v4_primary225_request'
assert 0 <= (datetime.now(timezone.utc) - datetime.fromisoformat(ready['observed_at'])).total_seconds() <= 900
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()
assert not OUT.exists(), 'One attempt only; preserve any earlier failure'
OUT.mkdir()
nonce = uuid.uuid4().hex
claim = {'owner_thread': OWNER, 'nonce': nonce, 'claimed_at': now(), 'head': HEAD,
 'purpose': 'ONE offline FilingFacts Node22 serial focused tests and optional prepare/audit/questions',
 'maximum_seconds': 30, 'scope': 'No deps/npm/build/Chrome/network/model/provider/resource/spend; no retries',
 'helper_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'authorization': 'Explicit lead conditional grant plus actual predecessor terminal/PG absence/guarded release; no inference from lock absence'}
started_tick = time.monotonic()
fd = os.open(LOCK, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
with os.fdopen(fd, 'w') as handle:
    handle.write(json.dumps(claim, indent=2) + '\n')
save(OUT / 'lease.json', claim)
worker = None
code = None
failure = None
released = False
try:
    env = {**os.environ, 'CANLI_SMOKE_NONCE': nonce}
    with (OUT / 'worker.log').open('xb') as log:
        worker = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--worker'],
          cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
          preexec_fn=lambda: os.nice(10), env=env)
        save(OUT / 'process.json', {'pid': worker.pid, 'pgid': worker.pid, 'started_at': now(),
          'command': [sys.executable, str(Path(__file__).resolve()), '--worker']})
        try:
            code = worker.wait(timeout=max(0.1, 27 - (time.monotonic() - started_tick)))
        except subprocess.TimeoutExpired:
            code = 124
            failure = 'aggregate bounded job timed out; no retry'
finally:
    if worker is not None:
        assert worker.pid != os.getpgrp()
        if not pg_absent(worker.pid):
            os.killpg(worker.pid, signal.SIGTERM)
            try:
                worker.wait(timeout=0.5)
            except subprocess.TimeoutExpired:
                pass
            if not pg_absent(worker.pid):
                os.killpg(worker.pid, signal.SIGKILL)
        worker.wait(timeout=1)
        for _ in range(20):
            if pg_absent(worker.pid):
                break
            time.sleep(0.025)
        assert pg_absent(worker.pid), 'Own process group still present; do not announce closure'
    with LOCK.open('rb') as handle:
        current = json.load(handle)
        observed = os.fstat(handle.fileno())
    identity = LOCK.stat()
    assert current['owner_thread'] == OWNER and current['nonce'] == nonce
    assert (observed.st_dev, observed.st_ino) == (identity.st_dev, identity.st_ino), 'Lock changed before guard'
    LOCK.unlink()
    released = True
    save(OUT / 'terminal.json', {'schema': 'canli.filingfacts-offline-smoke-terminal.v1', 'source': HEAD,
      'nonce': nonce, 'exit_code': code, 'failure': failure, 'ended_at': now(),
      'seconds': time.monotonic() - started_tick, 'guarded_released': released,
      'owned_process_group_absent': worker is None or pg_absent(worker.pid),
      'source_head_unchanged': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD,
      'checkout_clean': not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip(),
      'node_version': subprocess.check_output([NODE, '--version'], text=True).strip(),
      'model_calls': 0, 'cloud_resources_created': 0, 'financial_holds_created': 0, 'spend': 0})
print((OUT / 'terminal.json').read_text())
sys.exit(code if code is not None else 1)
