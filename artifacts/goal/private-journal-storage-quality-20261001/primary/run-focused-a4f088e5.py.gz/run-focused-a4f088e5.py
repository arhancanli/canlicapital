"""One explicitly granted local check. Preparing this file does not execute tests."""
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/Users/arhancanli/canlicapital-journal-store-20261001')
HEAD = 'a4f088e576e9ac57ce4f66d7e8d0b571fe5635c4'
OWNER = '01a0f5c2-92d6-71f2-99f2-0cdf8dc19a23'
LEAD = '01a0f6ae-ec9e-75c0-b7e9-01ba7ab69b1c'
NODE = '/Users/arhancanli/.nvm/versions/node/v22.23.2/bin/node'
LOCK = Path('/Users/arhancanli/traceaxiom-coordination-claude-codex/HEAVY.lock')
REQUEST = HERE / 'focused-request-a4f088e5.json'
OUT = HERE / 'attempt-1'


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as handle:
        handle.write(json.dumps(value, indent=2) + '\n')


def pg_absent(pgid):
    try:
        os.killpg(pgid, 0)
        return False
    except ProcessLookupError:
        return True


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True, timeout=1).strip()


def source_ok(request):
    return git('rev-parse', 'HEAD') == HEAD and not git('status', '--porcelain=v1') and all(
        sha(ROOT / path) == expected for path, expected in request['source_sha256'].items())


def claim_matches(nonce):
    fd = os.open(LOCK, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as handle:
        observed = os.fstat(handle.fileno())
        assert observed.st_size <= 4096, 'Unexpected lease size'
        claim = json.load(handle)
    named = LOCK.lstat()
    assert (named.st_dev, named.st_ino) == (observed.st_dev, observed.st_ino), 'Lease pathname changed'
    assert claim['owner_thread'] == OWNER and claim['nonce'] == nonce, 'Foreign lease; never unlink it'
    return observed


if '--worker' in sys.argv:
    nonce = os.environ['CANLI_JOURNAL_CHECK_NONCE']
    claim_matches(nonce)
    deadline = float(os.environ['CANLI_JOURNAL_CHECK_DEADLINE'])
    request = json.loads(REQUEST.read_bytes())
    assert source_ok(request), 'Worker source changed before execution'
    version = subprocess.check_output([NODE, '--version'], text=True,
        timeout=max(0.01, deadline - time.monotonic())).strip()
    save(OUT / 'node-version.json', {'observed_at': now(), 'executable': NODE, 'version': version})
    command = request['command']
    assert command == [NODE, '--test', '--test-concurrency=1',
        'mcp-execution/test/journal-store.test.mjs', 'mcp-execution/test/packaging.test.mjs']
    started = now()
    tick = time.monotonic()
    with (OUT / 'focused-tests.log').open('xb') as log:
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
            timeout=max(0.01, deadline - time.monotonic()))
    save(OUT / 'focused-tests-terminal.json', {'command': command, 'started_at': started,
        'ended_at': now(), 'seconds': time.monotonic() - tick, 'exit_code': result.returncode})
    sys.exit(result.returncode)


assert len(sys.argv) == 3 and sys.argv[1] == '--grant', 'Provide the actual explicit lead grant path'
grant_path = Path(sys.argv[2]).resolve()
grant = json.loads(grant_path.read_bytes())
request = json.loads(REQUEST.read_bytes())
assert grant['lead_thread'] == LEAD and grant['executor_thread'] == OWNER
assert grant['lead_explicit_conditional_grant'] and grant['source'] == HEAD
assert grant['max_wall_seconds'] == 30 and grant['child_wall_seconds'] == 27 and grant['max_attempts'] == 1
assert grant['helper']['path'] == str(Path(__file__).resolve()) and grant['helper']['sha256'] == sha(Path(__file__))
assert grant['request']['path'] == str(REQUEST) and grant['request']['sha256'] == sha(REQUEST)
assert datetime.now(timezone.utc) < datetime.fromisoformat(grant['latestClaimBefore'])
ready = grant['predecessorClosure']
assert ready['lead_or_observer_relay'] and ready['actual_terminal_observed']
assert ready['owned_process_group_absent'] and ready['guarded_released']
assert 0 <= (datetime.now(timezone.utc) - datetime.fromisoformat(ready['observed_at'])).total_seconds() <= 900
assert request['head'] == HEAD and source_ok(request) and git('log', '-1', '--format=%G?') == 'G'
assert not OUT.exists(), 'Exactly one attempt; retain any previous attempt instead of retrying'

nonce = uuid.uuid4().hex
claim = {'owner_thread': OWNER, 'nonce': nonce, 'claimed_at': now(), 'head': HEAD,
    'purpose': 'ONE Node22 serial private journal storage and packaging check, 15+3 written cases',
    'maximum_seconds': 30, 'child_maximum_seconds': 27, 'helper_sha256': sha(Path(__file__)),
    'grant': {'path': str(grant_path), 'sha256': sha(grant_path)},
    'scope': 'No retry/dependencies/build/browser/network/model/resource/hold/spend/publication',
    'authorization': 'Explicit lead grant and current predecessor closure; never inferred from lock absence'}
tick = time.monotonic()
fd = os.open(LOCK, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
with os.fdopen(fd, 'w') as handle:
    initial = os.fstat(handle.fileno())
    handle.write(json.dumps(claim, indent=2) + '\n')
worker = None
code = 1
failures = []
released = False
cleanup_absent = False
cleanup_at = None
try:
    OUT.mkdir(mode=0o700)
    save(OUT / 'lease.json', claim)
    env = {**os.environ, 'CANLI_JOURNAL_CHECK_NONCE': nonce,
        'CANLI_JOURNAL_CHECK_DEADLINE': str(tick + 27)}
    with (OUT / 'worker.log').open('xb') as log:
        worker = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--worker'],
            cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
            preexec_fn=lambda: os.nice(10), env=env)
        save(OUT / 'process.json', {'pid': worker.pid, 'pgid': worker.pid, 'started_at': now(),
            'command': [sys.executable, str(Path(__file__).resolve()), '--worker']})
        try:
            code = worker.wait(timeout=max(0.01, tick + 27 - time.monotonic()))
        except subprocess.TimeoutExpired:
            code = 124
            failures.append('One bounded worker timed out; no retry')
except BaseException as error:
    failures.append(f'{type(error).__name__}: {error}')
finally:
    try:
        if worker is not None:
            assert worker.pid != os.getpgrp(), 'Never signal the supervising process group'
            if not pg_absent(worker.pid):
                try:
                    os.killpg(worker.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    worker.wait(timeout=0.5)
                except subprocess.TimeoutExpired:
                    pass
                if not pg_absent(worker.pid):
                    try:
                        os.killpg(worker.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
            worker.wait(timeout=0.5)
            until = time.monotonic() + 0.75
            while not pg_absent(worker.pid) and time.monotonic() < until:
                time.sleep(0.025)
        cleanup_absent = worker is None or pg_absent(worker.pid)
        cleanup_at = now()
        assert cleanup_absent, 'Own process group remains; retain the lease'
        save(OUT / 'cleanup.json', {'observed_at': cleanup_at, 'pgid': worker.pid if worker else None,
            'owned_process_group_absent': cleanup_absent, 'observation': 'ESRCH' if worker else 'No worker started'})
        observed = claim_matches(nonce)
        assert (observed.st_dev, observed.st_ino) == (initial.st_dev, initial.st_ino), 'Lease inode changed'
        LOCK.unlink()
        released = True
    except BaseException as error:
        code = code if code else 1
        failures.append(f'Cleanup/guard failure: {type(error).__name__}: {error}')
    ended = now()
    elapsed = time.monotonic() - tick
    try:
        clean_after = source_ok(request)
    except BaseException as error:
        clean_after = False
        failures.append(f'After-source observation: {type(error).__name__}: {error}')
    version_file = OUT / 'node-version.json'
    stage_code = code
    if failures or not released or not cleanup_absent or not clean_after or elapsed > 30:
        code = code if code else 1
    terminal = {'schema': 'canli.private-journal-store-focused-terminal.v1', 'source': HEAD,
        'nonce': nonce, 'exit_code': code, 'worker_exit_code': stage_code,
        'failures': failures, 'ended_at': ended, 'seconds': elapsed,
        'owned_process_group_absent': cleanup_absent, 'cleanup_observed_at': cleanup_at,
        'guarded_released': released, 'cleanup_before_release': cleanup_absent and released,
        'source_head_and_pins_unchanged_and_clean': clean_after,
        'node_version': json.loads(version_file.read_bytes())['version'] if version_file.exists() else None,
        'model_calls': 0, 'cloud_resources_created': 0, 'financial_holds_created': 0, 'spend': 0}
    save(OUT / 'terminal.json', terminal)
    print(json.dumps(terminal, indent=2))

sys.exit(code if not failures and released and cleanup_absent and clean_after and elapsed <= 30 else 1)
