// Finite synthetic fixture emitter for a separately granted cross-language check.
// The private test key is generated in memory and is never printed or written.
import assert from 'node:assert/strict';
import { createHash, generateKeyPairSync } from 'node:crypto';
import { closeSync, constants, fstatSync, mkdirSync, openSync, readFileSync,
  writeFileSync } from 'node:fs';
import { isAbsolute, join } from 'node:path';
import { initializeJournalStore, appendJournalStore } from
  '/Users/arhancanli/canlicapital-journal-store-20261001/mcp-execution/src/journal-store.mjs';

assert.equal(process.argv.length, 3);
const output = process.argv[2];
assert.ok(isAbsolute(output));
mkdirSync(output, { mode: 0o700 }); // Exclusive new fixture directory; no recovery or removal.
const home = join(output, 'synthetic-home');
mkdirSync(home, { mode: 0o700 });
const { privateKey } = generateKeyPairSync('ed25519');
const source = 'c4403ddb517f805315807c7b7c8c364fc2aa65ff';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
function readPrivate(path) {
  const fd = openSync(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const stat = fstatSync(fd);
    assert.ok(stat.isFile() && stat.uid === process.getuid() && stat.nlink === 1);
    assert.equal(stat.mode & 0o7777, 0o600);
    assert.ok(stat.size <= 32768);
    const bytes = readFileSync(fd);
    assert.equal(bytes.length, stat.size);
    return bytes;
  } finally { closeSync(fd); }
}
function savePrivate(name, bytes) {
  const fd = openSync(join(output, name),
    constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 0o600);
  try { writeFileSync(fd, bytes); } finally { closeSync(fd); }
}
const snapshots = [];
function snapshot(name, entries) {
  const bytes = readPrivate(join(home, 'journal.jsonl'));
  savePrivate(name, bytes);
  snapshots.push({ file: name, entries, bytes: bytes.length, sha256: sha(bytes) });
}
const requests = [
  { operation_id: 'synthetic-python-genesis', body: { kind: 'config',
    payload: { purpose: 'offline-synthetic-only', escaped: 'line\nquote"slash\\del\u007f' },
    ts: '2026-10-01T00:00:00.000Z', expected_head: null } },
];
const initial = initializeJournalStore({ home, privateKey, operationId: requests[0].operation_id,
  payload: requests[0].body.payload, ts: requests[0].body.ts });
snapshot('01-genesis.jsonl', 1);
requests.push({ operation_id: 'synthetic-python-decision', body: { kind: 'decision',
  payload: { decision_id: 'synthetic-only', note: 'caf\u00e9 \u4e2d\u6587 \ud83e\uddea',
    fraction: 0.125, tiny_fraction: 0.0000001, nested: { flag: true, optional: null, values: [1, false] } },
  ts: '2026-10-01T00:00:01.000Z', expected_head: initial.entry_head } });
const decisionInput = { home, privateKey, operationId: requests[1].operation_id,
  kind: requests[1].body.kind, payload: requests[1].body.payload,
  ts: requests[1].body.ts, expectedHead: requests[1].body.expected_head };
const decision = appendJournalStore(decisionInput);
snapshot('02-decision-prefix.jsonl', 2);
requests.push({ operation_id: 'synthetic-python-mark', body: { kind: 'mark',
  payload: { marks: { SYNTH: 101.25 }, source: 'offline-synthetic-fixture' },
  ts: '2026-10-01T00:00:02.000Z', expected_head: decision.entry_head } });
const mark = appendJournalStore({ home, privateKey, operationId: requests[2].operation_id,
  kind: requests[2].body.kind, payload: requests[2].body.payload,
  ts: requests[2].body.ts, expectedHead: requests[2].body.expected_head });
snapshot('03-final-mark.jsonl', 3);
const initRetry = initializeJournalStore({ home, privateKey, operationId: requests[0].operation_id,
  payload: requests[0].body.payload, ts: requests[0].body.ts });
const decisionRetry = appendJournalStore(decisionInput);
assert.equal(initRetry.replayed, true);
assert.equal(decisionRetry.replayed, true);
assert.deepEqual({ ...initRetry, replayed: false }, initial);
assert.deepEqual({ ...decisionRetry, replayed: false }, decision);
const finalBytes = readPrivate(join(home, 'journal.jsonl'));
assert.equal(sha(finalBytes), snapshots[2].sha256);
const report = { schema: 'canli.synthetic-stored-journal-fixtures.v1', source,
  synthetic_only: true, private_key_stored: false, snapshots, requests,
  receipts: [initial, decision, mark, initRetry, decisionRetry],
  final_journal_unchanged_after_retries: true };
savePrivate('receipts.json', Buffer.from(JSON.stringify(report, null, 2) + '\n'));
console.log(JSON.stringify({ source, snapshots, receipts: report.receipts.length,
  synthetic_only: true, private_key_stored: false }));
