"""Finite independent stdlib receipt/prefix calculation. No JS imports or signing key."""
import hashlib
import json
import os
import pathlib
import stat
import sys

assert len(sys.argv) == 2
folder = pathlib.Path(sys.argv[1])
assert folder.is_absolute()


def read_private(name):
    fd = os.open(folder / name, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as handle:
        observed = os.fstat(handle.fileno())
        assert stat.S_ISREG(observed.st_mode) and observed.st_uid == os.getuid()
        assert stat.S_IMODE(observed.st_mode) == 0o600 and observed.st_nlink == 1
        assert observed.st_size <= 32768
        data = handle.read(32769)
        assert len(data) == observed.st_size
        return data


def digest(data):
    return 'sha256:' + hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True,
                      allow_nan=False).encode('ascii')


report = json.loads(read_private('receipts.json'))
assert report['schema'] == 'canli.synthetic-stored-journal-fixtures.v1'
assert report['source'] == 'c4403ddb517f805315807c7b7c8c364fc2aa65ff'
assert report['synthetic_only'] is True and report['private_key_stored'] is False
names = ['01-genesis.jsonl', '02-decision-prefix.jsonl', '03-final-mark.jsonl']
assert [s['file'] for s in report['snapshots']] == names
journals = [read_private(name) for name in names]
lines = journals[-1].splitlines(keepends=True)
assert len(lines) == 3 and all(line.endswith(b'\n') for line in lines)
entries = [json.loads(line)['entry'] for line in lines]
assert len(report['requests']) == 3 and len(report['receipts']) == 5
requests = {item['operation_id']: item['body'] for item in report['requests']}
assert len(requests) == 3
for index, snapshot in enumerate(report['snapshots']):
    data = journals[index]
    assert data == b''.join(lines[:index + 1])
    assert snapshot == {'file': names[index], 'entries': index + 1,
                        'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    verdict = json.loads(read_private(names[index] + '.python-verdict.json'))
    assert verdict == {'valid': True, 'entries': index + 1, 'first_bad_line': None,
                       'reason': None, 'head': digest(lines[index][:-1])}

expected_receipts = []
for index, entry in enumerate(entries):
    metadata = entry['payload']['_canli_store']
    payload = {key: value for key, value in entry['payload'].items()
               if key != '_canli_store' and not (index == 0 and key == 'journal_key')}
    body = {'kind': entry['kind'], 'payload': payload, 'ts': entry['ts'],
            'expected_head': entry['prev']}
    assert body == requests[metadata['id']]
    request_hash = digest(canonical(body))
    assert metadata == {'id': metadata['id'], 'schema': 'canli.trade-journal.operation.v1',
                        'request_sha256': request_hash}
    prefix = b''.join(lines[:index + 1])
    expected_receipts.append({'operation_id': metadata['id'], 'request_sha256': request_hash,
                             'entry_seq': index, 'entry_head': digest(lines[index][:-1]),
                             'journal_prefix_sha256': digest(prefix),
                             'journal_prefix_bytes': len(prefix), 'replayed': False})
expected_receipts.extend([{**expected_receipts[0], 'replayed': True},
                          {**expected_receipts[1], 'replayed': True}])
assert report['receipts'] == expected_receipts
assert report['final_journal_unchanged_after_retries'] is True
assert read_private('synthetic-home/journal.jsonl') == journals[-1]
assert len(list((folder / 'synthetic-home').iterdir())) == 1
print(json.dumps({'schema': 'canli.independent-python-stored-receipts.v1',
                  'source': report['source'], 'valid': True, 'journals': 3,
                  'signed_entries': 3, 'receipts': 5, 'later_prefix_retries': 2,
                  'request_and_prefix_bindings_match': True,
                  'synthetic_only': True, 'hardware_or_latency_claim': False}))
