import { createServer } from '/Users/arhancanli/canlicapital-mcp-page-review-20261001/node_modules/vite/dist/node/index.js';
const server = await createServer({
  root: '/Users/arhancanli/canlicapital-mcp-page-review-20261001',
  cacheDir: '/Users/arhancanli/canlicapital-coordination-20261001/mcp-page-peer/vite-cache',
  optimizeDeps: { entries: ['developers.html', 'mcp-servers.html', 'mcp-servers/validation.html', 'mcp-servers/fundamentals.html', 'mcp-servers/research.html'] },
  server: { host: '127.0.0.1', port: 5298, strictPort: true },
});
await server.listen();
console.log('Independent read-only DEV server ready on127.0.0.1:5298. No prebuild/build/publication.');
