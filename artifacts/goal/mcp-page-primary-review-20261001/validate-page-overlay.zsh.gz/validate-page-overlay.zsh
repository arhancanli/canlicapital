#!/bin/zsh
set -eu
export PATH="/Users/arhancanli/.nvm/versions/node/v22.23.2/bin:/Users/arhancanli/.local/bin:$PATH"
CANLI_PAGE_SOURCE=$1
CANLI_PAGE_EXPECTED=$2
test "$(git -C "$CANLI_PAGE_SOURCE" rev-parse HEAD)" = "$CANLI_PAGE_EXPECTED"
test -z "$(git -C "$CANLI_PAGE_SOURCE" status --porcelain)"
export SITE_LANDING_DESIGN_SOURCE="$CANLI_PAGE_SOURCE"
. /Users/arhancanli/alphaforge/scripts/lib/site_snapshot.sh
CANLI_PAGE_PARENT=$(mktemp -d /tmp/canli-publish.XXXXXX)
trap 'site_snapshot_cleanup "$CANLI_PAGE_PARENT"' EXIT
site_snapshot_create "$CANLI_PAGE_PARENT"
if [ ! -e "$SITE_SNAPSHOT_ROOT/meridian/node_modules" ]; then
  ln -s "$CANLI_PAGE_SOURCE/node_modules" "$SITE_SNAPSHOT_ROOT/meridian/node_modules"
fi
python3 - "$CANLI_PAGE_SOURCE/node_modules" "$SITE_SNAPSHOT_ROOT/meridian/node_modules" <<'PY'
from pathlib import Path
import sys
assert Path(sys.argv[1]).resolve(strict=True) == Path(sys.argv[2]).resolve(strict=True)
PY
printf "Overlay dependency paths verified at %s\n" "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
node "$CANLI_PAGE_SOURCE/scripts/validate-deploy-snapshot.mjs" "$SITE_SNAPSHOT_ROOT/meridian"
printf 'Page overlay source hash: %s\n' "$SITE_SNAPSHOT_HASH"
printf 'Page overlay source commit: %s\n' "$(git -C "$CANLI_PAGE_SOURCE" rev-parse HEAD)"
printf 'Page overlay Node: %s\n' "$(node --version)"
test -z "$(git -C "$CANLI_PAGE_SOURCE" status --porcelain)"
