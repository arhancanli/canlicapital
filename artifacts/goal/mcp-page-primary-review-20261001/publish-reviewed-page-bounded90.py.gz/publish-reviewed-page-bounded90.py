import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import uuid

COORD = Path('/Users/arhancanli/canlicapital-coordination-20261001/analyzers')
LOCK = Path('/Users/arhancanli/traceaxiom-coordination-claude-codex/HEAVY.lock')
SOURCE = Path('/Users/arhancanli/canlicapital-mcp-page-publication-20261001')
PRODUCTION = Path('/Users/arhancanli/canlicapital-production-20260920')
ENGINE = Path('/Users/arhancanli/alphaforge')
COMMIT = '62d2a195b31a81dedbd9b7a897a76e2af95ae1fb'
PREVIOUS = '0d9c88c605d7abfda150bde87c95f8554672352e'
THREAD = '01a0f5c2-92d6-71f2-99f2-0cdf8dc19a23'

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def git(root, *args):
    return subprocess.run(['git', '-C', str(root), *args], check=True, capture_output=True).stdout.decode().strip()

def write_new(name, value):
    with (COORD / name).open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

def command(args, label, timeout=None):
    begin = time.monotonic()
    path = COORD / ('pr-349-primary-bounded90-' + label + '.log')
    with path.open('xb') as f:
        process = subprocess.Popen(args, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        write_new('pr-349-primary-bounded90-' + label + '-process.json', {'started_at': now(), 'pid': process.pid, 'pgid': process.pid, 'args': args})
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, 15)
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, 9)
                process.wait()
            code = 124
    result = {'ended_at': now(), 'exit_code': code, 'seconds': time.monotonic() - begin, 'pid': process.pid, 'pgid': process.pid, 'log': str(path), 'log_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    write_new('pr-349-primary-bounded90-' + label + '-terminal.json', result)
    print(json.dumps({label: result}), flush=True)
    if code:
        raise RuntimeError(label + ' failed with exit ' + str(code))
    return result

assert git(SOURCE, 'rev-parse', 'HEAD') == COMMIT
assert not git(SOURCE, 'status', '--porcelain')
nonce = uuid.uuid4().hex
lease = {'nonce': nonce, 'ownerThread': THREAD, 'sourceCommit': COMMIT, 'claimed_at': now(), 'purpose': 'One engine-overlay validator <=90s, then established bounded site publisher; explicit lead grant after Trace003 actual closure', 'validatorTimeboxSeconds': 90, 'publisherEstimatedSeconds': 120, 'publisherBounds': 'Existing per-call run_bounded contract; no additional build/browser/LH/model job'}
fd = os.open(LOCK, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
try:
    with os.fdopen(fd, 'w') as f:
        json.dump(lease, f, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())
    write_new('pr-349-primary-bounded90-publication-lease.json', lease)
    print(json.dumps({'claimed': lease}), flush=True)
    validation = command(['nice', '-n', '10', 'zsh', str(COORD / 'validate-page-overlay.zsh'), str(SOURCE), COMMIT], 'overlay', timeout=90)
    assert '416' in Path(validation['log']).read_text()
    assert git(SOURCE, 'rev-parse', 'HEAD') == COMMIT and not git(SOURCE, 'status', '--porcelain')
    activation = '''set -eu
. /Users/arhancanli/alphaforge/scripts/lib/bounded.sh
deploy_lock_acquire || exit 73
trap 'deploy_lock_release' EXIT
test "$(head -n 1 /Users/arhancanli/alphaforge/config/site_landing_design_source.txt)" = /Users/arhancanli/canlicapital-production-20260920
test -z "$(git -C /Users/arhancanli/canlicapital-production-20260920 status --porcelain)"
test "$(git -C /Users/arhancanli/canlicapital-production-20260920 rev-parse HEAD)" = 0d9c88c605d7abfda150bde87c95f8554672352e
git -C /Users/arhancanli/canlicapital-production-20260920 switch --detach 62d2a195b31a81dedbd9b7a897a76e2af95ae1fb
test -z "$(git -C /Users/arhancanli/canlicapital-production-20260920 status --porcelain)"
git -C /Users/arhancanli/canlicapital-production-20260920 rev-parse HEAD
'''
    command(['zsh', '-c', activation], 'activation')
    assert git(PRODUCTION, 'rev-parse', 'HEAD') == COMMIT and not git(PRODUCTION, 'status', '--porcelain')
    publisher_log = ENGINE / 'var/log/live_deploy.log'
    offset = publisher_log.stat().st_size
    write_new('pr-349-primary-bounded90-publisher-observation.json', {'started_at': now(), 'previous_log_bytes': offset, 'source_commit': COMMIT, 'production_clean': True})
    publication = command(['nice', '-n', '10', 'zsh', str(ENGINE / 'scripts/live_deploy_hourly.sh')], 'publisher')
    with publisher_log.open('rb') as f:
        f.seek(offset)
        raw = f.read()
    with (COORD / 'pr-349-primary-bounded90-publisher-engine.log').open('xb') as f:
        f.write(raw)
    assert b'=== hourly deploy OK ' in raw and b'[landing] prod: ' in raw and b'[app] prod: ' in raw, 'Publisher exit is insufficient without both recorded successful deployments'
    assert git(PRODUCTION, 'rev-parse', 'HEAD') == COMMIT and not git(PRODUCTION, 'status', '--porcelain')
    write_new('pr-349-primary-bounded90-publication-terminal.json', {'ended_at': now(), 'source_commit': COMMIT, 'previous_source_commit': PREVIOUS, 'tree': git(PRODUCTION, 'rev-parse', 'HEAD^{tree}'), 'production_clean': True, 'overlay': validation, 'publisher': publication, 'published_snapshot_sha256': (ENGINE / 'var/last_web_deploy.hash').read_text().strip(), 'engine_log_sha256': hashlib.sha256(raw).hexdigest(), 'public_alias_and_HTTP_checks_pending': True})
finally:
    current = json.loads(LOCK.read_text())
    assert current['nonce'] == nonce, 'Refuse to release a foreign lease'
    LOCK.unlink()
    release = {'released_at': now(), 'nonce': nonce, 'ownerThread': THREAD, 'nonce_guard_matched': True}
    write_new('pr-349-primary-bounded90-publication-release.json', release)
    print(json.dumps({'released': release}), flush=True)
