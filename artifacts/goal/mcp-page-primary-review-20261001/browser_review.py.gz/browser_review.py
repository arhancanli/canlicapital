import hashlib
import json
import platform
import signal
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright

ROOT = Path('/Users/arhancanli/canlicapital-mcp-page-review-20261001')
OUT = Path(__file__).parent
HEAD = 'ad7b9511f4f4e2afef1d0c13fccc4f36c5505c17'
BASE = 'http://127.0.0.1:5298'
ROUTES = ['/mcp-servers/validation', '/mcp-servers', '/mcp-servers/fundamentals', '/mcp-servers/research', '/developers']
rows, failures, notes = [], [], []
started = time.monotonic()
browser_version = None

def deadline(_signal, _frame):
    raise TimeoutError('Independent browser lease deadline150s')

def check(condition, message):
    if not condition:
        failures.append(message)

signal.signal(signal.SIGALRM, deadline)
signal.alarm(150)
try:
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        browser_version = browser.version
        try:
            for route in ROUTES:
                for width in [320, 1440]:
                    context = browser.new_context(viewport={'width': width, 'height': 900}, reduced_motion='reduce')
                    page = context.new_page()
                    page.set_default_timeout(8000)
                    page_errors, external, failed_requests = [], [], []
                    page.on('pageerror', lambda e: page_errors.append(str(e)))
                    page.on('request', lambda r: external.append(r.url) if urlparse(r.url).hostname not in ['127.0.0.1', None] else None)
                    page.on('requestfailed', lambda r: failed_requests.append({'url': r.url, 'failure': r.failure}))
                    response = page.goto(BASE + route, wait_until='networkidle')
                    page.evaluate('document.fonts.ready')
                    row = {'route': route, 'width': width, 'status': response.status, 'body_sha256': hashlib.sha256(response.body()).hexdigest(), 'page_errors': page_errors, 'external_requests': external, 'failed_requests': failed_requests}
                    check(response.status == 200, route + str(width) + ' status')
                    dom = page.evaluate("""() => ({canonical:document.querySelector('link[rel="canonical"]')?.href,width:innerWidth,scrollWidth:document.documentElement.scrollWidth,headingCount:document.querySelectorAll('h1').length,mainCount:document.querySelectorAll('main').length,fonts:[...document.fonts].filter(f=>f.status==='loaded').map(f=>({family:f.family,weight:f.weight}))})""")
                    row['dom'] = dom
                    check(dom['canonical'] == 'https://canlicapital.com' + route, route + str(width) + ' canonical')
                    check(dom['scrollWidth'] <= width, route + str(width) + ' page overflow')
                    check(dom['headingCount'] == dom['mainCount'] == 1, route + str(width) + ' semantics')
                    page.keyboard.press('Tab')
                    before_skip = page.evaluate("""() => {const x=document.activeElement,r=x.getBoundingClientRect();return {href:x.getAttribute('href'),visible:x.matches(':focus-visible'),outline:getComputedStyle(x).outline,top:r.top,left:r.left}}""")
                    page.keyboard.press('Enter')
                    after_skip = page.evaluate("""() => ({id:document.activeElement.id,main:document.activeElement.closest('main')!==null})""")
                    page.keyboard.press('Tab')
                    after_tab = page.evaluate("""() => {const x=document.activeElement,r=x.getBoundingClientRect(),h=document.querySelector('header[data-product-shell]').getBoundingClientRect();return {href:x.getAttribute('href'),inside_main:x.closest('main')!==null,visible:x.matches(':focus-visible'),top:r.top,header_bottom:h.bottom}}""")
                    row['skip'] = {'before': before_skip, 'after': after_skip, 'next_tab': after_tab}
                    check(before_skip['href'] == '#content' and before_skip['visible'] and before_skip['top'] >= 0, route + str(width) + ' visible first skip')
                    check(after_skip['id'] == 'content' and after_skip['main'], route + str(width) + ' skip main focus')
                    check(after_tab['inside_main'] and after_tab['visible'] and after_tab['top'] >= after_tab['header_bottom'], route + str(width) + ' next tab focus visible below header')
                    targets = []
                    for link in page.locator('.dev-page-index a').all():
                        link.scroll_into_view_if_needed()
                        link.focus()
                        target = link.evaluate("""x=>{const r=x.getBoundingClientRect(),hit=document.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return {href:x.getAttribute('href'),width:r.width,height:r.height,target_exists:!!document.getElementById(x.hash.slice(1)),center_hits_link:hit===x||x.contains(hit),focus_visible:x.matches(':focus-visible'),outline:getComputedStyle(x).outline}}""")
                        targets.append(target)
                        check(target['target_exists'] and target['center_hits_link'] and target['focus_visible'], route + str(width) + ' actual section target ' + target['href'])
                        if route != '/developers':
                            check(target['height'] >= 44, route + str(width) + ' section 44px height ' + target['href'])
                    row['section_targets'] = targets
                    if targets and route != '/developers':
                        link = page.locator('.dev-page-index a[href="#tools"]')
                        if link.count():
                            link.focus()
                            page.keyboard.press('Enter')
                            page.evaluate('() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))')
                            row['activated_tools_target'] = page.locator('#tools').evaluate("""x=>({top:x.getBoundingClientRect().top,header_bottom:document.querySelector('header[data-product-shell]').getBoundingClientRect().bottom})""")
                            check(row['activated_tools_target']['top'] >= row['activated_tools_target']['header_bottom'], route + str(width) + ' activated tools target below header')
                    tables = []
                    for i, table in enumerate(page.locator('table.dev-table').all()):
                        semantics = table.aria_snapshot().splitlines()[0]
                        check(semantics.startswith('- table'), route + str(width) + ' native table role')
                        dimensions = table.evaluate('x=>({width:x.clientWidth,scrollWidth:x.scrollWidth})')
                        table.focus()
                        focus = table.evaluate("""x=>{const r=x.getBoundingClientRect(),s=getComputedStyle(x);const clips=[];for(let p=x.parentElement;p;p=p.parentElement){const t=getComputedStyle(p),b=p.getBoundingClientRect();if(['auto','hidden','scroll','clip'].includes(t.overflowX)||['auto','hidden','scroll','clip'].includes(t.overflowY))clips.push({tag:p.tagName,class:p.className,overflowX:t.overflowX,overflowY:t.overflowY,left:b.left,top:b.top,right:b.right,bottom:b.bottom});}return {focused:document.activeElement===x,visible:x.matches(':focus-visible'),outline:s.outline,offset:s.outlineOffset,rect:{left:r.left,top:r.top,right:r.right,bottom:r.bottom},clipping_ancestors:clips}}""")
                        check(focus['focused'] and focus['visible'] and 'none' not in focus['outline'], route + str(width) + ' table computed keyboard focus')
                        if dimensions['scrollWidth'] > dimensions['width'] + 1:
                            table.evaluate('x=>x.scrollLeft=0')
                            page.keyboard.press('ArrowRight')
                            page.wait_for_timeout(160)
                            right = table.evaluate('x=>x.scrollLeft')
                            page.keyboard.press('ArrowLeft')
                            page.wait_for_timeout(160)
                            left = table.evaluate('x=>x.scrollLeft')
                            check(right > 0 and left < right, route + str(width) + ' native right/left table scroll')
                        else:
                            right, left = None, None
                        tables.append({'semantics': semantics, 'dimensions': dimensions, 'focus': focus, 'arrow_right': right, 'arrow_left': left})
                        if route == '/mcp-servers/validation' and width == 320 and i == 0:
                            page.locator('#tools').evaluate('x=>x.scrollIntoView({block:"start"})')
                            table.evaluate('x=>x.blur()')
                            page.screenshot(path=str(OUT / 'validation-320-table-unfocused.png'))
                            table.focus()
                            page.locator('#tools').evaluate('x=>x.scrollIntoView({block:"start"})')
                            page.screenshot(path=str(OUT / 'validation-320-table-focused.png'))
                            notes.append('Validation320 table focus screenshot requires actual visual inspection; computed outline alone is insufficient.')
                    row['tables'] = tables
                    if route != '/developers':
                        h1 = page.locator('h1')
                        row['heading_loaded_geometry'] = h1.evaluate("""x=>({width:x.getBoundingClientRect().width,height:x.getBoundingClientRect().height,font:getComputedStyle(x).fontFamily,size:getComputedStyle(x).fontSize,weight:getComputedStyle(x).fontWeight})""")
                        original = h1.evaluate('x=>x.style.fontFamily')
                        h1.evaluate("x=>x.style.fontFamily='\"Chakra Petch Fallback\"'")
                        page.evaluate("document.fonts.load('700 52px \"Chakra Petch Fallback\"')")
                        row['heading_forced_local_fallback_geometry'] = h1.evaluate("""x=>({width:x.getBoundingClientRect().width,height:x.getBoundingClientRect().height,font:getComputedStyle(x).fontFamily})""")
                        h1.evaluate('(x,value)=>x.style.fontFamily=value', original)
                    check(not page_errors, route + str(width) + ' page errors')
                    rows.append(row)
                    print(json.dumps({'route': route, 'width': width, 'failures_so_far': len(failures), 'elapsed_seconds': round(time.monotonic() - started, 2)}), flush=True)
                    context.close()
        finally:
            browser.close()
except Exception as e:
    failures.append(type(e).__name__ + ': ' + str(e))
finally:
    signal.alarm(0)
    result = {'schema': 'canli.mcp-page-peer-browser-review.v1', 'checked_at': datetime.now(timezone.utc).isoformat(), 'head': HEAD, 'base_url': BASE, 'served_mode': 'DEV Vite; separate from secondary BUILT/Lighthouse and primary LIVE evidence', 'python': platform.python_version(), 'node': subprocess.check_output(['node', '--version'], text=True).strip(), 'browser': browser_version, 'probe_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'server_probe_sha256': hashlib.sha256((OUT / 'serve.mjs').read_bytes()).hexdigest(), 'elapsed_seconds': time.monotonic() - started, 'completed_cases': len(rows), 'rows': rows, 'failures': failures, 'visual_inspection_notes': notes, 'limits': ['Independent Chromium keyboard/geometry/semantic cases only, no fresh axe/Lighthouse/full/Git-free run, Firefox/WebKit, screen reader or overall WCAG certification.', 'Forced available macOS fallback geometry is a scoped DOM measurement, not delayed-network CLS or a field performance score.', 'Developer external font requests remain captured, not represented as zero external requests for all routes.', 'No labels, submissions, implementation edits or publication; all owner objectives remain active.']}
    (OUT / 'browser-review.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'completed_cases': len(rows), 'browser': browser_version, 'elapsed_seconds': result['elapsed_seconds'], 'failures': failures}), flush=True)
raise SystemExit(1 if failures else 0)
