import gzip
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).parent
ROOT = Path('/Users/arhancanli/canlicapital-mcp-page-focus-review-20261001')
HEAD = '99af5fca424655a502397695c05e4b1fb9a85723'
BASE = 'fe68e73eb12d0f8c6a3a93eb4cf4f363c4ca1099'
REPO = 'repos/arhancanli/canlicapital/'
failures = []


def capture(name, args):
    if '--offline' in sys.argv:
        return json.loads((OUT / name).read_bytes())
    result = subprocess.run(args, capture_output=True, timeout=30)
    (OUT / name).write_bytes(result.stdout)
    if result.returncode:
        (OUT / (name + '.stderr')).write_bytes(result.stderr)
        raise RuntimeError('Read-only remote query failed: ' + name)
    return json.loads(result.stdout)


def check(condition, message):
    if not condition:
        failures.append(message)


ci = capture('pr-349-99af-ci.json', ['gh', 'pr', 'view', '349', '--repo',
    'arhancanli/canlicapital', '--json',
    'url,state,headRefOid,baseRefOid,statusCheckRollup,mergeable'])
commit = capture('pr-349-99af-commit.json', ['gh', 'api', REPO + 'commits/' + HEAD])
alerts = capture('pr-349-99af-codeql-alerts.json', ['gh', 'api',
    REPO + 'code-scanning/alerts?state=open&ref=refs/pull/349/merge&per_page=100'])
analyses = capture('pr-349-99af-codeql-analyses.json', ['gh', 'api',
    REPO + 'code-scanning/analyses?ref=refs/pull/349/merge&per_page=30'])
merge = capture('pr-349-99af-merge-ref-commit.json', ['gh', 'api',
    REPO + 'commits/refs/pull/349/merge'])
check(ci['headRefOid'] == HEAD and ci['baseRefOid'] == BASE and ci['state'] == 'OPEN',
      'Remote head/base/open PR still match signed frozen source')
checks = ci['statusCheckRollup']
check(len(checks) == 7 and all(r.get('conclusion') == 'SUCCESS' for r in checks),
      'All seven exact-head checks SUCCESS')
check(commit['sha'] == HEAD and commit['commit']['verification']['verified'],
      'GitHub remote SSH signature verified on exact head')
check(not alerts, 'No open merge-ref CodeQL alerts')
local_tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip()
check(merge['commit']['tree']['sha'] == local_tree, 'Latest CodeQL merge-ref tree equals reviewed head tree')
check({r['sha'] for r in merge['parents']} == {BASE, HEAD}, 'Latest merge-ref exact head/base parents')
latest = {}
for row in analyses:
    language = json.loads(row.get('environment') or '{}').get('language')
    if language not in latest:
        latest[language] = row
for language in ['javascript-typescript', 'python']:
    row = latest.get(language)
    check(row is not None, 'Latest CodeQL analysis exists ' + language)
    if row:
        check(row['commit_sha'] == merge['sha'] and row['results_count'] == 0
              and not row.get('error') and not row.get('warning'),
              'Latest ' + language + ' CodeQL analysis exact merge-ref, zero results/errors/warnings')
build = next(r for r in checks if r['name'] == 'vite production build')
job_id = build['detailsUrl'].rsplit('/', 1)[-1]
if '--offline' in sys.argv:
    log_data = gzip.decompress((OUT / 'pr-349-99af-ci-build.txt.gz').read_bytes())
else:
    log = subprocess.run(['gh', 'run', 'view', '--job', job_id, '--repo',
                         'arhancanli/canlicapital', '--log'], capture_output=True, timeout=30)
    check(log.returncode == 0, 'Exact-head remote production job log retrieved')
    log_data = log.stdout
    (OUT / 'pr-349-99af-ci-build.txt.gz').write_bytes(gzip.compress(log_data, mtime=0))
log_sha = hashlib.sha256(log_data).hexdigest()
lines = log_data.decode(errors='replace').splitlines()
needles = ['node: v', 'Node.js', 'node-version:', '# tests ', '# pass ', '# fail ',
           '0 errors', '0 warnings', '699', '683', '416', 'checked', 'stamped']
extract = '\n'.join(line for line in lines if any(n in line for n in needles))
(OUT / 'pr-349-99af-ci-build-extract.txt').write_text(extract + '\n')
result = {'schema': 'canli.mcp-table-focus-remote-recheck.v1',
          'observed_at': datetime.now(timezone.utc).isoformat(), 'head': HEAD, 'base': BASE,
          'verified_signature': commit['commit']['verification'], 'ci_checks': checks,
          'merge_ref': merge['sha'], 'merge_ref_tree': merge['commit']['tree']['sha'],
          'latest_language_analyses': latest, 'open_merge_ref_alerts': len(alerts),
          'ci_build_job': job_id, 'ci_build_log_raw_sha256': log_sha,
          'ci_build_log_raw_bytes': len(log_data),
          'probe_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'failures': failures, 'remote_result': 'PASS' if not failures else 'FAIL',
          'limits': ['Read-only exact-head remote CI and CodeQL evidence, no local heavy repeat.',
                     'CI success is separate from pending independent visible focus/native arrow proof.',
                     'No merge or website publication performed by reviewer.']}
(OUT / 'remote-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'head': HEAD, 'checks': len(checks), 'merge_ref': merge['sha'],
                  'remote_result': result['remote_result'], 'failures': failures}, indent=2))
raise SystemExit(1 if failures else 0)
