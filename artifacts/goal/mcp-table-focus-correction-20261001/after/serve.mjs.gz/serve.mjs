import { createServer } from '/Users/arhancanli/canlicapital-mcp-page-focus-review-20261001/node_modules/vite/dist/node/index.js';
const server = await createServer({
  root: '/Users/arhancanli/canlicapital-mcp-page-focus-review-20261001',
  cacheDir: '/Users/arhancanli/canlicapital-coordination-20261001/mcp-page-peer/focus-recheck/vite-cache',
  optimizeDeps: { entries: ['mcp-servers/validation.html', 'mcp-servers/fundamentals.html', 'mcp-servers/research.html'] },
  server: { host: '127.0.0.1', port: 5299, strictPort: true },
});
await server.listen();
console.log('Independent read-only focus recheck DEV server ready on127.0.0.1:5299. No build/publication.');
