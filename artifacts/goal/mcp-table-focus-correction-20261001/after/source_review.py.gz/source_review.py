import gzip
import hashlib
import json
import platform
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/Users/arhancanli/canlicapital-mcp-page-focus-review-20261001')
OUT = Path(__file__).parent
PREVIOUS = OUT.parent
HEAD = '99af5fca424655a502397695c05e4b1fb9a85723'
BEFORE = 'ad7b9511f4f4e2afef1d0c13fccc4f36c5505c17'
BASE = 'fe68e73eb12d0f8c6a3a93eb4cf4f363c4ca1099'
MANIFEST = 'artifacts/goal/mcp-page-quality-20261001.json'
CORRECTION = 'artifacts/goal/mcp-table-focus-correction-20261001.json'
SCOPE = ['css/mcp-pages.css', 'scripts/build-mcp-pages.mjs',
         'scripts/audit-developer-mcp-pages.py', 'mcp-servers.html',
         'mcp-servers/validation.html', 'mcp-servers/fundamentals.html',
         'mcp-servers/research.html', 'config/source-dates.json']
failures = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def check(condition, message):
    if not condition:
        failures.append(message)


def tree(ref):
    rows = {}
    for item in git('ls-tree', '-rz', ref).split(b'\0'):
        if item:
            metadata, name = item.split(b'\t', 1)
            mode, kind, oid = metadata.decode().split()
            rows[name.decode()] = {'mode': mode, 'kind': kind, 'oid': oid}
    return rows


actual_head = git('rev-parse', 'HEAD').decode().strip()
signature = git('log', '-1', '--format=%G?').decode().strip()
check(actual_head == HEAD, 'Own checkout must remain frozen at expected head')
check(signature == 'G', 'Local SSH signature verification')
check(not git('status', '--porcelain').strip(), 'Own tracked checkout clean')
before_tree, head_tree, base_tree = tree(BEFORE), tree(HEAD), tree(BASE)
delta = git('diff', '--name-only', BEFORE, HEAD).decode().splitlines()
expected_delta = {'css/mcp-pages.css', 'docs/goal/LOG.md', 'docs/goal/STATUS.md',
                  CORRECTION,
                  'artifacts/goal/mcp-table-focus-correction-20261001/before-focus-invisible.png',
                  'artifacts/goal/mcp-table-focus-correction-20261001/browser-review.json.gz',
                  'artifacts/goal/mcp-table-focus-correction-20261001/focus-screenshot-comparison.json.gz',
                  'artifacts/goal/mcp-table-focus-correction-20261001/review-findings.json.gz'}
check(set(delta) == expected_delta, 'Exact eight-path correction delta')
manifest = json.loads((ROOT / CORRECTION).read_bytes())
scope_rows = []
for path in SCOPE:
    data = (ROOT / path).read_bytes()
    same = before_tree[path] == head_tree[path]
    matches = sha(data) == manifest['current_source_sha256'][path]
    scope_rows.append({'path': path, 'sha256': sha(data),
                       'same_as_before': same, 'correction_manifest_match': matches})
    check(matches, 'Current correction source hash ' + path)
    check(same == (path != 'css/mcp-pages.css'), 'CSS-only measured source change ' + path)
before_css = git('show', BEFORE + ':css/mcp-pages.css').decode()
added_css = ('/* Draw keyboard focus inside both scrolling layers so neither clips it. */\n'
             'html[data-page="mcp-discovery"] .mcp-table :is(.dev-table, .cc-table-scroll):focus-visible { outline: 3px solid var(--dev-ink); outline-offset: -3px; }\n')
check((ROOT / 'css/mcp-pages.css').read_text().replace(added_css, '') == before_css,
      'Only intended two focus paint lines added to CSS')
old_delta = set(git('diff', '--name-only', BASE, BEFORE).decode().splitlines())
protected = [p for p in base_tree if p not in old_delta]
protected_mismatches = [p for p in protected if head_tree.get(p) != base_tree[p]]
check(not protected_mismatches, 'All previously protected base files remain byte exact')
old_source = json.loads((PREVIOUS / 'source-review.json').read_bytes())
archive_rows = []
for row in old_source['archives']:
    path = row['path']
    data = (ROOT / path).read_bytes()
    match = (head_tree[path] == before_tree[path] and sha(data) == row['sha256'])
    archive_rows.append({'path': path, 'sha256': sha(data), 'unchanged_match': match})
    check(match, 'Old compressed archive byte preservation ' + path)
check(len(archive_rows) == 84, 'Exactly 84 old archives preserved')
old_manifest_sha = sha((ROOT / MANIFEST).read_bytes())
check(head_tree[MANIFEST] == before_tree[MANIFEST], 'Old measurement manifest byte exact')
check(old_manifest_sha == manifest['historical_measurement_manifest_sha256'],
      'Old manifest historical hash unchanged')
before_rows = []
for row in manifest['before_receipts']:
    data = (ROOT / row['path']).read_bytes()
    raw = gzip.decompress(data)
    original = PREVIOUS / Path(row['path']).name.removesuffix('.gz')
    match = (sha(data) == row['gzip_sha256'] and sha(raw) == row['raw_sha256']
             and len(raw) == row['raw_bytes'] and original.read_bytes() == raw)
    before_rows.append({'path': row['path'], 'gzip_sha256': sha(data),
                        'raw_sha256': sha(raw), 'exact_own_before_receipt': match})
    check(match, 'Retained initial peer evidence exact ' + row['path'])
png = ROOT / 'artifacts/goal/mcp-table-focus-correction-20261001/before-focus-invisible.png'
check(sha(png.read_bytes()) == manifest['before_screenshot_sha256']
      == sha((PREVIOUS / 'validation-320-table-focused.png').read_bytes()),
      'Original invisible focus screenshot preserved')
check(manifest['independent_browser_recheck'] is None, 'No premature independent correction PASS')
diff_check = subprocess.run(['git', 'diff', '--check', BASE, HEAD], cwd=ROOT,
                            capture_output=True, text=True)
check(diff_check.returncode == 0, 'PR diff whitespace check against actual base')
prior = {}
for name in ['source-review-initial.json', 'source_review_initial.py',
             'source-binding-baseline.json', 'source-review.json',
             'browser-review.json', 'review-findings.json', 'browser-lease.json']:
    prior[name] = sha((PREVIOUS / name).read_bytes())
check(prior['source-review-initial.json'] == 'd65a0e1d2dd2bfa2b8d0662299415d53bf81cd12896293c3e52e21d936280231',
      'Initial broad-binding failed receipt remains exact')
check(prior['source_review_initial.py'] == '2e84e428bed28610cdac4d894d020d477662db12935b91c9a4a1ab73b087d7d8',
      'Initial failed source probe remains exact')
result = {'schema': 'canli.mcp-table-focus-source-recheck.v1',
          'checked_at': datetime.now(timezone.utc).isoformat(), 'head': HEAD,
          'before_head': BEFORE, 'base': BASE, 'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
          'signature': signature, 'python': platform.python_version(),
          'probe_sha256': sha(Path(__file__).read_bytes()), 'changed_paths': delta,
          'scope': scope_rows, 'protected_base_files_unchanged': len(protected),
          'protected_mismatches': protected_mismatches, 'old_archive_count': len(archive_rows),
          'archives': archive_rows, 'historical_manifest_sha256': old_manifest_sha,
          'retained_before_receipts': before_rows, 'prior_receipt_sha256': prior,
          'diff_check_exit': diff_check.returncode, 'diff_check_output': diff_check.stdout + diff_check.stderr,
          'failures': failures, 'source_result': 'PASS' if not failures else 'FAIL',
          'browser_result': 'PENDING explicit lease and actual visible pixels/native arrow check',
          'limits': ['Source-only extension. No new Lighthouse/axe/full/Git-free/build or score.',
                     'Old performance/raw source hashes remain historical; only CSS changed of eight scope paths.',
                     'Inherited 21 source-date mismatches retain separate baseline and original failed receipts.',
                     'No implementation, publication, labels, model, MCP release or protected dataset/journal/source edits. All owner objectives remain active.']}
(OUT / 'source-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['head', 'tree', 'signature', 'source_result',
                                      'protected_base_files_unchanged', 'old_archive_count', 'failures']}, indent=2))
raise SystemExit(1 if failures else 0)
