import hashlib
import json
import platform
import signal
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

from PIL import Image, ImageChops
from playwright.sync_api import sync_playwright

ROOT = Path('/Users/arhancanli/canlicapital-mcp-page-focus-review-20261001')
OUT = Path(__file__).parent
HEAD = '99af5fca424655a502397695c05e4b1fb9a85723'
BASE_URL = 'http://127.0.0.1:5299'
ROUTES = ['validation', 'fundamentals', 'research']
rows, failures = [], []
started = time.monotonic()
browser_version = None


def check(condition, message):
    if not condition:
        failures.append(message)


def deadline(_signal, _frame):
    raise TimeoutError('Independent focus recheck hard deadline60s')


def frame(page):
    page.evaluate('() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))')


def native_tab(page, target):
    # Actual Tab into the target from its preceding enabled visible tab stop.
    previous = target.evaluate('''x => {
      const list = [...document.querySelectorAll('a[href],button,input,select,textarea,[tabindex]')]
        .filter(y => y.tabIndex >= 0 && !y.disabled && !y.closest('[inert]')
          && y.getClientRects().length && getComputedStyle(y).visibility === 'visible');
      const index = list.indexOf(x);
      if (index < 1) throw new Error('Missing previous native tab stop');
      const p = list[index-1]; p.focus({preventScroll:true});
      return {tag:p.tagName,href:p.getAttribute('href'),class:p.className};
    }''')
    page.keyboard.press('Tab')
    return previous


def focus_state(target):
    return target.evaluate('''x => {
      const s=getComputedStyle(x), r=x.getBoundingClientRect();
      const clips=[];
      for(let p=x.parentElement;p;p=p.parentElement){
        const t=getComputedStyle(p),b=p.getBoundingClientRect();
        if(['auto','hidden','scroll','clip'].includes(t.overflowX)
            || ['auto','hidden','scroll','clip'].includes(t.overflowY))
          clips.push({class:p.className,x:b.x,y:b.y,width:b.width,height:b.height,
                      overflowX:t.overflowX,overflowY:t.overflowY});
      }
      return {focused:document.activeElement===x,focus_visible:x.matches(':focus-visible'),
              outline_color:s.outlineColor,outline_width:s.outlineWidth,
              outline_style:s.outlineStyle,outline_offset:s.outlineOffset,
              tabindex:x.getAttribute('tabindex'),client_width:x.clientWidth,
              scroll_width:x.scrollWidth,role:x.getAttribute('role'),
              label:x.getAttribute('aria-label'),
              rect:{x:r.x,y:r.y,width:r.width,height:r.height},clipping_ancestors:clips};
    }''')


def element_check(page, target, label):
    previous = native_tab(page, target)
    page.evaluate('(x) => window.scrollBy(0,x.getBoundingClientRect().top-170)', target.element_handle())
    target.evaluate('x => x.scrollLeft=0')
    frame(page)
    state = focus_state(target)
    check(state['focused'] and state['focus_visible'], label + ' actual Tab keyboard focus')
    check(state['outline_color'] == 'rgb(7, 20, 30)' and state['outline_width'] == '3px'
          and state['outline_style'] == 'solid' and state['outline_offset'] == '-3px',
          label + ' scoped dark inset outline computed')
    check(state['rect']['y'] >= 170-1, label + ' focus top visible below header')
    focused = OUT / (label + '-focused.png')
    unfocused = OUT / (label + '-unfocused.png')
    page.screenshot(path=str(focused), animations='disabled')
    target.evaluate('x => x.blur()')
    frame(page)
    unfocused_state = focus_state(target)
    check(not unfocused_state['focused'] and not unfocused_state['focus_visible'],
          label + ' blur reference has no target keyboard focus')
    check(unfocused_state['rect'] == state['rect'], label + ' focus/blur geometry unchanged')
    page.screenshot(path=str(unfocused), animations='disabled')
    f, u = Image.open(focused).convert('RGB'), Image.open(unfocused).convert('RGB')
    difference = ImageChops.difference(f, u)
    pixels = sum(a != b for a, b in zip(f.getdata(), u.getdata()))
    rect = state['rect']
    x0, x1 = max(0, int(rect['x'])), min(f.width, int(rect['x']+rect['width']))
    y0 = max(0, int(rect['y']))
    top_focus_ink = top_reference_ink = top_difference = 0
    for y in range(y0, min(f.height,y0+4)):
        for x in range(x0,x1):
            fp, up = f.getpixel((x,y)), u.getpixel((x,y))
            top_focus_ink += fp == (7,20,30)
            top_reference_ink += up == (7,20,30)
            top_difference += fp != up
    check(pixels > 0 and top_difference > 0 and top_focus_ink > top_reference_ink,
          label + ' actual visible dark focus pixels inside top edge')
    # Re-enter through the normal Tab sequence before testing native arrows.
    native_tab(page, target)
    target.evaluate('x => x.scrollLeft=0')
    right = left = None
    if state['scroll_width'] > state['client_width']+1:
        page.keyboard.press('ArrowRight')
        page.wait_for_timeout(170)
        right = target.evaluate('x => x.scrollLeft')
        page.keyboard.press('ArrowLeft')
        page.wait_for_timeout(170)
        left = target.evaluate('x => x.scrollLeft')
        check(right > 0 and left < right, label + ' native ArrowRight/Left scroll')
    return {'previous_tab_stop': previous, 'focus': state,
            'focus_blur_different_pixels': pixels, 'difference_bbox': difference.getbbox(),
            'top_edge_different_pixels': top_difference,
            'top_edge_focus_ink_pixels': top_focus_ink,
            'top_edge_unfocused_ink_pixels': top_reference_ink,
            'focused_png': focused.name, 'focused_sha256': hashlib.sha256(focused.read_bytes()).hexdigest(),
            'unfocused_png': unfocused.name, 'unfocused_sha256': hashlib.sha256(unfocused.read_bytes()).hexdigest(),
            'native_arrow_right': right, 'native_arrow_left': left,
            'arrow_limit': None if right is not None else 'No horizontal overflow in this unmodified viewport; arrow scroll inapplicable.'}


signal.signal(signal.SIGALRM, deadline)
signal.alarm(60)
try:
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == HEAD
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        browser_version = browser.version
        try:
            for route in ROUTES:
                for width in [320,1440]:
                    context = browser.new_context(viewport={'width':width,'height':900},reduced_motion='reduce')
                    try:
                        page = context.new_page()
                        page.set_default_timeout(5000)
                        errors, external, request_failures = [], [], []
                        page.on('pageerror',lambda e:errors.append(str(e)))
                        page.on('request',lambda r:external.append(r.url) if urlparse(r.url).hostname not in ['127.0.0.1',None] else None)
                        page.on('requestfailed',lambda r:request_failures.append({'url':r.url,'failure':r.failure}))
                        response = page.goto(BASE_URL+'/mcp-servers/'+route,wait_until='networkidle')
                        page.evaluate('document.fonts.ready')
                        page.keyboard.press('Tab')
                        table = page.locator('table.dev-table')
                        region = page.locator('.mcp-table .cc-table-scroll')
                        check(response.status==200 and table.count()==1 and region.count()==1, route+str(width)+' route/table/wrapper')
                        semantics = table.aria_snapshot().splitlines()[0]
                        check(semantics.startswith('- table'),route+str(width)+' native table role')
                        original_region = focus_state(region)
                        normal = element_check(page,table,route+'-'+str(width)+'-table')
                        original_style = table.get_attribute('style')
                        natural_wrapper = original_region['tabindex']=='0'
                        if not natural_wrapper:
                            # Bounded DOM width fixture activates the existing ResizeObserver.
                            # It verifies wrapper paint/arrows without claiming normal MCP content overflows it.
                            table.evaluate('x=>x.style.minWidth=(x.parentElement.clientWidth+120)+"px"')
                            frame(page)
                        check(region.get_attribute('tabindex')=='0',route+str(width)+' overflow wrapper native tab stop')
                        wrapper = element_check(page,region,route+'-'+str(width)+'-wrapper')
                        wrapper['mode'] = 'Unmodified actual focusable wrapper' if natural_wrapper else 'Controlled table min-width +120px DOM fixture; existing ResizeObserver automatically made wrapper focusable'
                        check(wrapper['focus']['role']=='region' and bool(wrapper['focus']['label']), route+str(width)+' overflow wrapper labeled region')
                        table.evaluate('(x,style)=>style===null?x.removeAttribute("style"):x.setAttribute("style",style)',original_style)
                        region.evaluate('x=>x.scrollLeft=0')
                        frame(page)
                        restored = focus_state(region)
                        check(restored['tabindex']==original_region['tabindex'],route+str(width)+' original wrapper state restored')
                        check(page.evaluate('document.documentElement.scrollWidth')<=width, route+str(width)+' document no overflow')
                        check(not errors and not external and not request_failures,route+str(width)+' no page errors/external/failed requests')
                        row={'route':'/mcp-servers/'+route,'width':width,'status':response.status,
                             'response_body_sha256':hashlib.sha256(response.body()).hexdigest(),
                             'table_semantics':semantics,'wrapper_original':original_region,
                             'table':normal,'wrapper':wrapper,'wrapper_restored':restored,
                             'page_errors':errors,'external_requests':external,'failed_requests':request_failures}
                        rows.append(row)
                        print(json.dumps({'route':route,'width':width,'completed_cases':len(rows),
                                          'failures_so_far':len(failures),'elapsed_seconds':round(time.monotonic()-started,3)}),flush=True)
                    finally:
                        context.close()
        finally:
            browser.close()
except Exception as e:
    failures.append(type(e).__name__+': '+str(e))
finally:
    signal.alarm(0)
    result={'schema':'canli.mcp-table-focus-browser-recheck.v1','observed_at':datetime.now(timezone.utc).isoformat(),
            'head':HEAD,'served_mode':'Independent DEV Vite; separate from historical BUILT/LH/LIVE',
            'base_url':BASE_URL,'node':subprocess.check_output(['node','--version'],text=True).strip(),
            'python':platform.python_version(),'browser':browser_version,
            'probe_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'server_probe_sha256':hashlib.sha256((OUT/'serve.mjs').read_bytes()).hexdigest(),
            'elapsed_seconds':time.monotonic()-started,'completed_cases':len(rows),'element_checks':2*len(rows),
            'rows':rows,'failures':failures,'automated_result':'PASS' if not failures and len(rows)==6 else 'FAIL',
            'human_visual_inspection':'PENDING independent viewing of actual focused captures',
            'limits':['Six Chromium responsive DEV cases at320/1440; normal native table focus plus labeled wrapper overflow fixture when wrapper naturally nonfocusable.',
                      'Controlled width fixture is disclosed and restored; not a claim normal MCP content scrolls the wrapper at those widths.',
                      'Actual Tab and native arrows used; pixel difference and dark top-edge counts checked, manual capture review still required.',
                      'No Lighthouse/axe/full/Git-free/build, score, delayed-network CLS, Firefox/WebKit/screen reader or complete WCAG certification.',
                      'No implementation changes, labels, submissions, model calls, website publication or MCP release. All owner objectives remain active.']}
    (OUT/'browser-review.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'head':HEAD,'completed_cases':len(rows),'element_checks':2*len(rows),
                      'browser':browser_version,'elapsed_seconds':result['elapsed_seconds'],
                      'automated_result':result['automated_result'],'failures':failures}),flush=True)
raise SystemExit(1 if failures or len(rows)!=6 else 0)
