import json
import os
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

LOCK = Path('/Users/arhancanli/traceaxiom-coordination-claude-codex/HEAVY.lock')
LOCAL = Path(__file__).with_name('browser-lease.json')
OWNER = '01a0f6dd-2bbf-7d00-8853-1732594b4a20'

if sys.argv[1] == 'claim':
    assert not LOCAL.exists(), 'Preserve prior lease evidence; no implicit reruns'
    grant = Path(__file__).with_name('capacity-grant.json')
    eligibility = Path(__file__).with_name('source-review.json')
    remote = Path(__file__).with_name('remote-review.json')
    g = json.loads(grant.read_bytes())
    assert g['lead_explicit_grant'] and g['primary_source_eligible'] and g['prior_owner_actual_cleanup_release']
    assert json.loads(eligibility.read_bytes())['source_result'] == 'PASS'
    assert json.loads(remote.read_bytes())['remote_result'] == 'PASS'
    lease={'owner_thread':OWNER,'nonce':uuid.uuid4().hex,
           'claimed_at':datetime.now(timezone.utc).isoformat(),
           'purpose':'CanliCapital349 ONE independent visible focus/native arrow correction recheck',
           'head':'99af5fca424655a502397695c05e4b1fb9a85723','maximum_seconds':150,
           'browser_deadline_seconds':60,'scope':'ONE serial Chromium DEV browser/own server/cache; no LH/full/axe/build/model/cloud/publisher',
           'authorization':'Explicit lead after Proveloom actual cleanup/release plus primary source eligibility; preserved capacity-grant.json. Absence not permission.'}
    fd=os.open(LOCK,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    try:
        os.write(fd,(json.dumps(lease,indent=2)+'\n').encode())
    finally:
        os.close(fd)
    LOCAL.write_text(json.dumps(lease,indent=2)+'\n')
    print(json.dumps(lease))
elif sys.argv[1] == 'release':
    lease=json.loads(LOCAL.read_bytes())
    with LOCK.open('rb') as f:
        actual=json.load(f);stat=os.fstat(f.fileno())
    current=LOCK.stat()
    assert actual['owner_thread']==OWNER and actual['nonce']==lease['nonce'], 'Refuse other owner nonce'
    assert (current.st_dev,current.st_ino)==(stat.st_dev,stat.st_ino), 'Lock changed during guard'
    LOCK.unlink()
    lease['guarded_released_at']=datetime.now(timezone.utc).isoformat()
    LOCAL.write_text(json.dumps(lease,indent=2)+'\n')
    print(json.dumps({'released':True,'nonce':lease['nonce'],'released_at':lease['guarded_released_at']}))
else:
    raise ValueError('claim or release')
