#!/bin/zsh
set -eu
export PATH="/Users/arhancanli/.nvm/versions/node/v22.23.2/bin:/Users/arhancanli/.local/bin:$PATH"
CANLI_HEADER_SOURCE=/Users/arhancanli/canlicapital-continuation-20261001
test "$(git -C "$CANLI_HEADER_SOURCE" rev-parse HEAD)" = 0d9c88c605d7abfda150bde87c95f8554672352e
test -z "$(git -C "$CANLI_HEADER_SOURCE" status --porcelain)"
export SITE_LANDING_DESIGN_SOURCE="$CANLI_HEADER_SOURCE"
. /Users/arhancanli/alphaforge/scripts/lib/site_snapshot.sh
CANLI_HEADER_PARENT=$(mktemp -d "${TMPDIR:-/tmp}/canli-publish.XXXXXX")
trap 'site_snapshot_cleanup "$CANLI_HEADER_PARENT"' EXIT
site_snapshot_create "$CANLI_HEADER_PARENT"
ln -s "$CANLI_HEADER_SOURCE/node_modules" "$SITE_SNAPSHOT_ROOT/meridian/node_modules"
node "$CANLI_HEADER_SOURCE/scripts/validate-deploy-snapshot.mjs" "$SITE_SNAPSHOT_ROOT/meridian"
printf 'Header overlay source hash: %s\n' "$SITE_SNAPSHOT_HASH"
printf 'Header overlay source commit: %s\n' "$(git -C "$CANLI_HEADER_SOURCE" rev-parse HEAD)"
printf 'Header overlay Node: %s\n' "$(node --version)"
test -z "$(git -C "$CANLI_HEADER_SOURCE" status --porcelain)"
